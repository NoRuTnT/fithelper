<template>
    <div>
      <h2>KakaoView</h2>
      <hr>
      <KakaoMap/>
    </div>
  </template>
  
  <script setup>
  import KakaoMap from '../components/kakao/KakaoMap.vue';
  
  
  </script>
  
  <style  scoped>
  
  </style>