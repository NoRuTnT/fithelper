<!-- 회원가입 기능을 담당하는 vue-->
<template>
    <div>
        <RouterView/>
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>