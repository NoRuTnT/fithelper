package com.ssafy.board.controller;

public class TrainerRestController {

}
