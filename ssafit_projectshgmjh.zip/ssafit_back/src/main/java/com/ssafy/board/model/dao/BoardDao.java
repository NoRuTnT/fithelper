package com.ssafy.board.model.dao;

import java.util.List;

import com.ssafy.board.model.dto.Board;
import com.ssafy.board.model.dto.SearchCondition;


public interface BoardDao {
	public List<Board> selectAll();

	public Board selectOne(int id);

	public void insertBoard(Board board);

	public void deleteBoard(int id);

	public void updateBoard(Board board);

	public void updateViewCnt(int id);

	public List<Board> search(SearchCondition condition);
	/** 좋아요 개수를 update함*/
	public void updateLikeCntUp(int boardId);
	
	public void updateLikeCntDown(int boardId);
	
}
