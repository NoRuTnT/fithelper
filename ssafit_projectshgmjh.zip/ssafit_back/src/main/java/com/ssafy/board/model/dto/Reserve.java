package com.ssafy.board.model.dto;

public class Reserve {

}
